=======
History
=======

1.2 (2019-10-01)
------------------

* First release on PyPI.
