=====
Usage
=====

To use time_space_reductions in a project::

    import time_space_reductions
